﻿// lib/config/auth_config.dart

/// ✅ 统一使用 HTTPS 回调（移动端 & Web 一致）
/// - OAuth: https://swaply.cc/auth/callback
/// - Reset Password: https://swaply.cc/reset-password
///
/// 配置提示：
///   • Supabase Auth → URL Configuration：把上面两个 URL 加入 Redirect URLs；Site URL 设为 https://swaply.cc
///   • Android/iOS 不再需要 cc.swaply.app 自定义 scheme 的 login-callback/reset-password 过滤器
///   • DeepLinkService 仅需处理 HTTPS 回调

/// ✅ OAuth 回调（iOS/Android/Web）
const String kAuthRedirectUri = 'https://swaply.cc/auth/callback';
const String kAuthWebRedirectUri = 'https://swaply.cc/auth/callback';

/// ✅ 密码重置回调（iOS/Android/Web）
const String kResetPasswordRedirectUri = 'https://swaply.cc/reset-password';
const String kResetPasswordWebRedirectUri = 'https://swaply.cc/reset-password';

/// ✅ 动态获取当前平台的 OAuth 回调（现统一为 HTTPS）
String getAuthRedirectUri() => kAuthRedirectUri;

/// ✅ 动态获取当前平台的密码重置回调（现统一为 HTTPS）
String getResetPasswordRedirectUri() => kResetPasswordRedirectUri;
